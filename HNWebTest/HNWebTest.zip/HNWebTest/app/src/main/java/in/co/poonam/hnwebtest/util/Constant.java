package in.co.poonam.hnwebtest.util;

public class Constant {

    public final static String baseUrl = "http://tech599.com/tech599.com/johngov/";
    public final static String partyqusetUrl = "partyquest/services/api_get_all_events.php/";
}

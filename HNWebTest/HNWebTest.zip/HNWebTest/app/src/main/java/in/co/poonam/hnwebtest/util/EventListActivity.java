package in.co.poonam.hnwebtest.util;

import androidx.appcompat.app.AppCompatActivity;
import in.co.poonam.hnwebtest.R;

import android.os.Bundle;

public class EventListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);
    }
}
